See .env.example, run npm install, npm run dev, then create admin via scripts/create_admin.js.
