Install Expo CLI, run npm install, then npm run start. Update API URL in app.json -> expo.extra.apiUrl.
